package cn.johnny;

import com.sun.istack.internal.NotNull;

import java.util.*;

public class DigitsButtons {
    private static final Map<Integer, List<String>> DIGITS_MAP = new LinkedHashMap<Integer, List<String>>();

    static {
        DIGITS_MAP.put(0, Collections.singletonList(""));
        DIGITS_MAP.put(1, Collections.singletonList(""));
        DIGITS_MAP.put(2, Arrays.asList("A", "B", "C"));
        DIGITS_MAP.put(3, Arrays.asList("D", "E", "F"));
        DIGITS_MAP.put(4, Arrays.asList("G", "H", "I"));
        DIGITS_MAP.put(5, Arrays.asList("J", "K", "L"));
        DIGITS_MAP.put(6, Arrays.asList("M", "N", "O"));
        DIGITS_MAP.put(7, Arrays.asList("P", "Q", "R", "S"));
        DIGITS_MAP.put(8, Arrays.asList("T", "U", "V"));
        DIGITS_MAP.put(9, Arrays.asList("W", "X", "Y", "Z"));
    }

    /**
     * input digits to output combination letter
     * @param input digits
     * @return combination letter
     */
    public static List<String> click(@NotNull List<Integer> input) {
        List<String> output = new ArrayList<>();
        for (int i = 0; i < input.size(); i++) {
            Integer digit = input.get(i);
            List<String> letters = DIGITS_MAP.get(digit);
            List<String> tmp = new ArrayList<>();
            if (i == 0) {
                output.addAll(letters);
            } else {
                for (String beforeCmb : output) {
                    for (String letter : letters) {
                        String afterCmb = beforeCmb + "" + letter;
                        tmp.add(afterCmb);
                    }
                }
                output = tmp;
            }
        }
        return output;
    }

}
