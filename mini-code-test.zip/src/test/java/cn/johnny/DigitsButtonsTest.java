package cn.johnny;

import org.junit.Assert;

import java.util.Arrays;
import java.util.List;

public class DigitsButtonsTest {

    @org.junit.Test
    public void click() {
        List<String> output = DigitsButtons.click(Arrays.asList(0, 3, 9));
        Assert.assertEquals(String.valueOf(output), "[DW, DX, DY, DZ, EW, EX, EY, EZ, FW, FX, FY, FZ]");
        List<String> output1 = DigitsButtons.click(Arrays.asList(2, 3));
        Assert.assertEquals(String.valueOf(output1), "[AD, AE, AF, BD, BE, BF, CD, CE, CF]");
    }
}